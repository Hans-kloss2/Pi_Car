const $ = (...params) => document.querySelector(...params);

const sendRequest = async value => await fetch('/', { method: 'post', body: `submit_button=${ value }` }).then(data => data.json());

const inputs = {
  up: $('#up'),
  down: $('#down'),
  left: $('#left'),
  right: $('#right'),
  stop: $('#stop'),
};

Object.entries(inputs).forEach(([key, element]) => {
  console.log(element);
  element.addEventListener('click', async event => {
    await sendRequest(key);
  });
});

document.onkeydown = async (event) => {
  switch (event.keyCode) {
    case 37:
      await sendRequest('left');
      break;
    case 38:
      await sendRequest('up');
      break;
    case 39:
      await sendRequest('right');
      break;
    case 40:
      await sendRequest('down');
      break;
    case 32:
      await sendRequest('stop');
      break;
  }
};
